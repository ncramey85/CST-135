// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import javafx.collections.ObservableList;
import java.io.File;
import java.util.*;

public class ProcessCustomerQueue {

    private String customerName;
    private String inventoryName;
    private String inventoryType;
    private static Scanner sc;

    LinkedList<ProcessCustomerQueue> customerQueue = new LinkedList<>();

    public void createCustomer(String customerName, String inventoryName, String inventoryType) {
        this.customerName = customerName;
        this.inventoryName = inventoryName;
        this.inventoryType = inventoryType;}

    public LinkedList<ProcessCustomerQueue> readCustomerQueue() {

        String customerQueueFile = "Customer Queue.csv";
        try {
            sc = new Scanner(new File(customerQueueFile));
            sc.useDelimiter("[,\n]");

//Header Line Skipped
            String header = sc.nextLine();

        while (sc.hasNextLine()) {
                String nextLine = sc.nextLine();
                String[] lineArray = nextLine.split(",");
                String customerName = lineArray[0];
                String inventoryName = lineArray[1];
                String inventoryType = lineArray[2];

                ProcessCustomerQueue customer = new ProcessCustomerQueue();
                customer.createCustomer(customerName, inventoryName, inventoryType);
                customerQueue.offer(customer);}}
        catch (Exception e) {
            AlertWindow.display("ERROR", "Cannot Read Customer Queue");}
        
        return customerQueue;}
    

    public String processCustomer(ObservableList<Inventory> inventoryObservableList, LinkedList<ProcessCustomerQueue> customerQueueLinkedList) {
        RecursiveSearch recursiveSearch = new RecursiveSearch();
        csvFile csvFile = new csvFile();
        Random random = new Random();
        String textArea;
        int i;
        if (recursiveSearch.recursiveSearch(inventoryObservableList, customerQueueLinkedList.getFirst().inventoryName) == -1
                || inventoryObservableList.get(recursiveSearch.recursiveSearch(inventoryObservableList, customerQueueLinkedList.getFirst().inventoryName))
                .getQuantity() == 0) {
            i = random.nextInt(inventoryObservableList.size());
            String inventoryType = customerQueueLinkedList.getFirst().inventoryType;
            while (inventoryObservableList.get(i).getQuantity() == 0 ||
                    !inventoryType.equalsIgnoreCase(inventoryObservableList.get(i).productID.substring(0, inventoryObservableList.get(i).productID.length() - 1))) {
                i = random.nextInt(inventoryObservableList.size());
            }
            textArea = customerQueueLinkedList.getFirst().inventoryName + " not available!" + "\nNew inventory: " + inventoryObservableList.get(i).getName() + " Price: " + inventoryObservableList.get(i).getPrice();
            inventoryObservableList.get(i).changeQuantity(-1);}

//Searches for customers request and annontes it in the "purchase" 
        else {
            textArea = "inventory: " + inventoryObservableList.get(recursiveSearch.recursiveSearch(inventoryObservableList,
                    customerQueueLinkedList.getFirst().inventoryName)).getName() + " Price: " +
                    inventoryObservableList.get(recursiveSearch.recursiveSearch(inventoryObservableList,
                            customerQueueLinkedList.getFirst().inventoryName)).getPrice();
            inventoryObservableList.get(recursiveSearch.recursiveSearch(inventoryObservableList, customerQueueLinkedList.getFirst().inventoryName))
                    .changeQuantity(-1);}

//Removes first customer after being served. 
        customerQueueLinkedList.poll();

//Writes to inventory file updating the exchange
        csvFile.writeCsvFile(inventoryObservableList);

//String Data to textarea Log
        return textArea;}
    

    public String getCustomerName() {
        return customerName;}
    

    public String getinventoryName() {
        return inventoryName;}
    

    public String getinventoryType() {
        return inventoryType;}

    @Override
    public String toString() {
        return String.format("%-10s%-10s", customerName, inventoryName);}}
