// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

//Subclass of Snack
public class Candy extends Snack {

//No constructors
	public Candy() {}
	
//Constructors
	Candy(String name, String brand, double price, String image, int quantity, String productID) {

		super.setName(name);
		super.setPrice(price);
		super.setBrand(brand);
		super.setImage(image);
		super.setQuantity(quantity);
		super.setProductID(productID);}

	public String getName() { return super.getName();}
	
	public String getBrand() { return super.getBrand();}

	public double getPrice() { return super.getPrice();}

	public String getImage() { return super.getImage(); }
	
    public int getQuantity() {return super.getQuantity();}
    
    public String getProductID() {return super.getProductID();}

//toString method
	@Override
	public String toString() {
		return String.format("%-15s%-15s%-15.2f%-12s%-12s%-12.2f%-12d%-12.2f", name, brand, price, productID);}}
