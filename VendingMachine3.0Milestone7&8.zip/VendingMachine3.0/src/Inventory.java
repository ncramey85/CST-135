// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

public class Inventory {

	//Variables
	int quantity;
	String name;
	double price;
	String image;
	String brand;
	String productID;

//No Constructors
	Inventory() {}

//Constructors
	public Inventory (String name, String brand, double price, String image, int quantity, String productID)
	{
		this.name = name;
		this.price = price;
		this.image = image;
		this.quantity = quantity;
		this.productID = productID;}
	
//Product creator for global inventory management that doesn't need extra variables
    public Inventory(String name, Double price, Integer quantity, String productID){
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.productID = productID;}
   
//Setters & Getters
	String getName() { return name; }

	protected void setName(String name) { this.name = name; }

	public String getBrand() {return brand;}
	
	protected void setBrand(String brand) {this.brand = brand;}
	
	double getPrice() { return price; }
	
	protected void setPrice(double price) { this.price = price; }
	
	public String getImage() { return image; }

	protected void setImage(String image) { this.image = image; }
	
	public int getQuantity() {return quantity;}

    public void setQuantity(int quantity) {this.quantity = this.quantity + quantity;}
    
    public String getProductID() {return productID;}
    
    public void setProductID(String productID) {this.productID = productID;}
    
    public void changeQuantity(int quantity) {this.quantity = this.quantity + quantity;}
    

	//toString method
	public String toString() {
		return name + " " + price + " " + quantity + " " + productID;}}
