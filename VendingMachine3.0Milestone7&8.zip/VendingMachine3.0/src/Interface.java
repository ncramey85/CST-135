// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.util.Duration;
import javafx.stage.Modality;
import java.io.IOException;
import java.awt.Desktop;
import java.io.File;

public class Interface extends Application {

//Variables needed for entire application 
    TableView<Drink> drinkTableView;
    TableView<Chips> chipsTableView;
    TableView<Candy> candyTableView;
    TableView<Gum> gumTableView;
    TableView<Inventory> checkoutTableView;
    TableView<Inventory> inventoryTableView;
    ObservableList<Inventory> checkoutObservableList = FXCollections.observableArrayList();
    ObservableList<Inventory> globalInventoryObservableList = FXCollections.observableArrayList();
    Button payButton;
    BorderPane checkoutBottom = new BorderPane();
    HBox totalBox = new HBox(25);

//Animations for various Scenes
    TranslateTransition translate = new TranslateTransition();
    ScaleTransition scaleTransition = new ScaleTransition();

//Imageview Changes for each animation     
    ImageView changingImageView2;
    Button addDrinksButton;
    Button addChipsButton;
    Button addCandyButton;
    Button addGumButton;

//Animation StackPanes
    StackPane drinksStack = new StackPane();
    StackPane chipsStack = new StackPane();
    StackPane gumStack = new StackPane();
    StackPane candyStack = new StackPane();

    Dispensary dispensary;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        dispensary = new Dispensary();

//Code Tester
        Global_Inventory_Management globalInventoryManagement = new Global_Inventory_Management();
        globalInventoryObservableList = globalInventoryManagement.GlobalInventoryManagement();

//Scenes Declared
        Scene home, drinksScene, chipsScene, candyScene, gumScene, checkoutScene, inventoryScene;
        
//Root Layout for each scene
        BorderPane homeRoot = new BorderPane();
        BorderPane drinkRoot = new BorderPane();
        BorderPane chipsRoot = new BorderPane();
        BorderPane candyRoot = new BorderPane();
        BorderPane gumRoot = new BorderPane();
        BorderPane checkoutRoot = new BorderPane();
        BorderPane inventoryRoot = new BorderPane();
        
//Scenes
        home = new Scene(homeRoot, 600, 600);
        drinksScene = new Scene(drinkRoot, 600, 475);
        chipsScene = new Scene(chipsRoot, 600, 475);
        candyScene = new Scene(candyRoot, 600, 475);
        gumScene = new Scene(gumRoot, 600, 475);
        checkoutScene = new Scene(checkoutRoot, 600, 475);
        inventoryScene = new Scene(inventoryRoot, 600, 650);


//HomePage Images
         Image drinksImage = new Image("image/drinks.jpg");
         ImageView drinksImageView = new ImageView(drinksImage);
         drinksImageView.setFitHeight(200);
         drinksImageView.setFitWidth(200);

         Image chipsImage = new Image("image/chips.jpg");
         ImageView chipsImageView = new ImageView(chipsImage);
         chipsImageView.setFitHeight(200);
         chipsImageView.setFitWidth(200);

         Image candyImage = new Image("image/candy-cigs.jpg");
         ImageView candyImageView = new ImageView(candyImage);
         candyImageView.setFitHeight(200);
         candyImageView.setFitWidth(200);

         Image gumImage = new Image("image/chewing-gum.jpg");
         ImageView gumImageView = new ImageView(gumImage);
         gumImageView.setFitHeight(200);
         gumImageView.setFitWidth(200);

         Image backImage = new Image("image/back.png");
         ImageView backImageView1 = new ImageView(backImage);
         backImageView1.setFitHeight(50);
         backImageView1.setFitWidth(50);

         ImageView backImageView2 = new ImageView(backImage);
         backImageView2.setFitHeight(50);
         backImageView2.setFitWidth(50);

         ImageView backImageView3 = new ImageView(backImage);
         backImageView3.setFitHeight(50);
         backImageView3.setFitWidth(50);

         ImageView backImageView4 = new ImageView(backImage);
         backImageView4.setFitHeight(50);
         backImageView4.setFitWidth(50);

         ImageView backImageView5 = new ImageView(backImage);
         backImageView5.setFitHeight(50);
         backImageView5.setFitWidth(50);

         ImageView backImageView6 = new ImageView(backImage);
         backImageView6.setFitHeight(50);
         backImageView6.setFitWidth(50);

         Image checkoutImage = new Image("image/checkout.png");
         ImageView checkoutImageView1 = new ImageView(checkoutImage);
         checkoutImageView1.setFitHeight(50);
         checkoutImageView1.setFitWidth(50);

         ImageView checkoutImageView2 = new ImageView(checkoutImage);
         checkoutImageView2.setFitHeight(50);
         checkoutImageView2.setFitWidth(50);

         ImageView checkoutImageView3 = new ImageView(checkoutImage);
         checkoutImageView3.setFitHeight(50);
         checkoutImageView3.setFitWidth(50);

         ImageView checkoutImageView4 = new ImageView(checkoutImage);
         checkoutImageView4.setFitHeight(50);
         checkoutImageView4.setFitWidth(50);

         ImageView checkoutImageView5 = new ImageView(checkoutImage);
         checkoutImageView5.setFitHeight(50);
         checkoutImageView5.setFitWidth(50);

         Image payImage = new Image("image/pay.png");
         ImageView payImageView = new ImageView(payImage);
         payImageView.setFitHeight(50);
         payImageView.setFitWidth(50);

         Image deleteImage = new Image("image/delete.jpg");
         ImageView deleteImageView = new ImageView(deleteImage);
         deleteImageView.setFitHeight(50);
         deleteImageView.setFitWidth(50);

         Image inventoryImage = new Image("image/OVgGBMp.png");
         ImageView inventoryImageView = new ImageView(inventoryImage);
         inventoryImageView.setFitHeight(90);
         inventoryImageView.setFitWidth(90);

//Animation Functions
         translate.setDuration(Duration.seconds(2));
         translate.setToX(350);
         translate.setToY(120);

//Animation Transitions Times
          scaleTransition.setDuration(Duration.seconds(2));
          scaleTransition.setToX(.5);
          scaleTransition.setToY(.5);

//Labels for each Inventory scene
          Label drinkSelectionLabel = new Label("MAKE ONE SELECTION PER CLICK");
          Label chipSelectionLabel = new Label("MAKE ONE SELECTION PER CLICK");
          Label gumSelectionLabel = new Label("MAKE ONE SELECTION PER CLICK");
          Label candySelectionLabel = new Label("MAKE ONE SELECTION PER CLICK");
          Label inventoryLabel = new Label("CURRENT INVENTORY");

//HomePage Buttons
          Button drinksButton = new Button("DRINKS");
          drinksButton.setGraphic(drinksImageView);
          drinksButton.setOnAction(e -> primaryStage.setScene(drinksScene));

          Button chipsButton = new Button("CHIPS");
          chipsButton.setGraphic(chipsImageView);
          chipsButton.setOnAction(e -> primaryStage.setScene(chipsScene));

          Button candyButton = new Button("CANDY");
          candyButton.setGraphic(candyImageView);
          candyButton.setOnAction(e -> primaryStage.setScene(candyScene));

          Button gumButton = new Button("GUM");
          gumButton.setGraphic(gumImageView);
          gumButton.setOnAction(e -> primaryStage.setScene(gumScene));

//Back Buttons for each scene
          Button backButton1 = new Button();
          backButton1.setGraphic(backImageView1);
          backButton1.setOnAction(e -> primaryStage.setScene(home));

          Button backButton2 = new Button();
          backButton2.setGraphic(backImageView2);
          backButton2.setOnAction(e -> primaryStage.setScene(home));

          Button backButton3 = new Button();
          backButton3.setGraphic(backImageView3);
          backButton3.setOnAction(e -> primaryStage.setScene(home));

          Button backButton4 = new Button();
          backButton4.setGraphic(backImageView4);
          backButton4.setOnAction(e -> primaryStage.setScene(home));

          Button backButton5 = new Button();
          backButton5.setGraphic(backImageView5);
          backButton5.setOnAction(e -> primaryStage.setScene(home));

          Button backButton6 = new Button();
          backButton6.setGraphic(backImageView6);
          backButton6.setOnAction(e -> primaryStage.setScene(home));

//Management Inventory Scene 
          Button inventoryButton = new Button();
          inventoryButton.setGraphic(inventoryImageView);
          inventoryButton.setOnAction(e -> {
          AlertWindow.display("MANAGEMENT", "MANAGERS ONLY");
          Stage window = new Stage();

//Blocks other Windows
          window.initModality(Modality.APPLICATION_MODAL);
          window.setTitle("Management GUI");
          window.setResizable(false);

          Label label = new Label();
          label.setStyle("-fx-font-size: 14");
          label.setText("Enter Password:");
          String passwordMaster = "admin";
          Button passwordButton = new Button("Enter");
          TextField passwordTextField = new TextField();
          passwordTextField.setPromptText("Enter Password:  ");
          passwordTextField.setOnAction(e2 -> {
          passwordButton.fire();});
          passwordButton.setStyle("-fx-font-size: 14");
          passwordButton.setOnAction(e1 -> {
        	  if (passwordTextField.getText().equals(passwordMaster)) {
                AlertWindow.display("Correct Password", "Access Granted");
                primaryStage.setScene(inventoryScene);
                window.close();}
             else {
                AlertWindow.display("WRONG PASSWORD", "Incorrect Password!");
                passwordTextField.clear();}});

          HBox hBox = new HBox(25);
          HBox hBox2 = new HBox(25);
          BorderPane borderPane = new BorderPane();
          borderPane.setPadding(new Insets(25, 25, 25, 25));
          hBox.getChildren().addAll(label, passwordTextField);
          hBox.setAlignment(Pos.CENTER);
          hBox2.getChildren().add(passwordButton);
          hBox2.setAlignment(Pos.CENTER);
          borderPane.setCenter(hBox);
          borderPane.setBottom(hBox2);

//Displays Windows and holds off before initially closing.
          Scene scene = new Scene(borderPane, 450, 125);
          window.setScene(scene);
          window.showAndWait();});

//Button for csvFile to update/change inventory
          Button inventoryCSV = new Button("Save Updates");
          inventoryCSV.setMinWidth(200);
          inventoryCSV.setOnAction(e -> {
            csvFile.writeCsvFile(dispensary.inventory);
            AlertWindow.display(".csv doc", "File Saved!");});
//Button for PO when inventory is low
          Button lowInventoryPurchase = new Button("Create Purchase Order");
          lowInventoryPurchase.setMinWidth(200);
          lowInventoryPurchase.setOnAction(e -> {
            	
//Views inventory each time its ran to see if anything is low
          Restock restock = new Restock();
          restock.purchaseLowProducts(dispensary.inventory);
          AlertWindow.display("Purchase Order", "PO Saved");});

//Button to Restock once PO is made.
          Button restockInventory = new Button("Restock from PO");
          restockInventory.setOnAction(e -> {
           Restock restock = new Restock();
           restock.restockProducts(dispensary.inventory);
           inventoryTableView.refresh();
           drinkTableView.refresh();
           candyTableView.refresh();
           chipsTableView.refresh();
           gumTableView.refresh();
           csvFile.writeCsvFile(dispensary.inventory);
           restock.purchaseLowProducts(dispensary.inventory);
           AlertWindow.display("Success", "Vending Machine Stocked");});
       
//AddNewProduct Button          
          Button addNewProductButton = new Button("Add a New Product");
          addNewProductButton.setMinWidth(200);
          addNewProductButton.setOnAction(e -> {
              AddNewProductDisplay addNewProductDisplay = new AddNewProductDisplay();
              addNewProductDisplay.addNewProduct(dispensary.inventory, dispensary.drinksList, dispensary.chipsList, dispensary.candyList,dispensary.gumList);
              inventoryTableView.refresh();
              drinkTableView.refresh();
              chipsTableView.refresh();
              candyTableView.refresh();
              gumTableView.refresh();});

//Search Button
            Button searchButton = new Button("Search Inventory");
            searchButton.setMinWidth(200);
            searchButton.setOnAction(e -> {
            Stage window = new Stage();

//Blocks other Windows while searching
            window.initModality(Modality.APPLICATION_MODAL);
            window.setTitle("Inventory Search");
            window.setResizable(false);
 
            Label label = new Label();
            label.setStyle("-fx-font-size: 14");
            label.setText("Enter product name: ");
            Button searchButton2 = new Button("SEARCH");
            TextField textField = new TextField();
            textField.setPromptText("Search by product name: ");
            textField.setOnAction(e2 -> {
            searchButton2.fire();});

            searchButton2.setStyle("-fx-font-size: 14");
            searchButton2.setOnAction(e1 -> {
                RecursiveSearch recursiveSearch = new RecursiveSearch();
                if (recursiveSearch.recursiveSearch(dispensary.inventory, textField.getText()) == -1) {
                   AlertWindow.display("Not Found", "Product Not Found");}
                else {
                    AlertWindow.display("Product Found", "PRODUCT FOUND! \n File Row: " +
                    (recursiveSearch.recursiveSearch(dispensary.inventory, textField.getText()) + 2) + "\nQuantity: " +
                    dispensary.inventory.get(recursiveSearch.recursiveSearch(dispensary.inventory, textField.getText())).getQuantity());
                    try {
                        if (Desktop.isDesktopSupported()) {
                            Desktop.getDesktop().open(new File("Blue Group Inventory.csv"));}}
                    catch (IOException ioe) {}
                    inventoryTableView.getSelectionModel().select(recursiveSearch.recursiveSearch(dispensary.inventory, textField.getText()));
                    window.close();}});

            HBox hBox = new HBox(25);
            HBox hBox2 = new HBox(25);
            BorderPane borderPane = new BorderPane();
            borderPane.setPadding(new Insets(25, 25, 25, 25));

            hBox.getChildren().addAll(label, textField);
            hBox.setAlignment(Pos.CENTER);

            hBox2.getChildren().add(searchButton2);
            hBox2.setAlignment(Pos.CENTER);

            borderPane.setCenter(hBox);
            borderPane.setBottom(hBox2);

//Display Window and waits before closing 
            Scene scene = new Scene(borderPane, 400, 125);
            window.setScene(scene);
            window.showAndWait();});
            
//Customer Queue Button
            Button customerQueue = new Button("Customer Queue");
            customerQueue.setMinWidth(200);
            customerQueue.setOnAction(e -> {
                CustomerDisplay customerDisplay = new CustomerDisplay();
                customerDisplay.display(dispensary.inventory);
                inventoryTableView.refresh();});

//Checkout Buttons for each Scene
           Button checkoutButton1 = new Button();
           checkoutButton1.setGraphic(checkoutImageView1);
           checkoutButtons(primaryStage, dispensary, checkoutScene, payImageView, checkoutButton1);

           Button checkoutButton2 = new Button();
           checkoutButton2.setGraphic(checkoutImageView2);
           checkoutButtons(primaryStage, dispensary, checkoutScene, payImageView, checkoutButton2);

           Button checkoutButton3 = new Button();
           checkoutButton3.setGraphic(checkoutImageView3);
           checkoutButtons(primaryStage, dispensary, checkoutScene, payImageView, checkoutButton3);

           Button checkoutButton4 = new Button();
           checkoutButton4.setGraphic(checkoutImageView4);
           checkoutButtons(primaryStage, dispensary, checkoutScene, payImageView, checkoutButton4);

           Button checkoutButton5 = new Button();
           checkoutButton5.setGraphic(checkoutImageView5);
           checkoutButtons(primaryStage, dispensary, checkoutScene, payImageView, checkoutButton5);

//Pay and Delete Buttons
           Button deleteButton = new Button("Clear Selection");
           deleteButton.setGraphic(deleteImageView);
           deleteButton.setOnAction(e -> {
               try {
                   dispensary.total = dispensary.total - checkoutTableView.getSelectionModel().getSelectedItem().getPrice();
                   checkoutTableView.getSelectionModel().getSelectedItem().changeQuantity(1);
                   checkoutObservableList.remove(checkoutTableView.getSelectionModel().getSelectedItem());
                   checkoutTableView.refresh();
                   drinkTableView.refresh();
                   chipsTableView.refresh();
                   candyTableView.refresh();
                   gumTableView.refresh();
                   inventoryTableView.refresh();
                   totalBox.getChildren().remove(payButton);
                   if (dispensary.total.toString().endsWith("25") || dispensary.total.toString().endsWith("75")) {
                       payButton = new Button("$" + dispensary.total.toString());
                       payButton.setOnAction(e1 -> {
                           AlertWindow.display("Success", "SUCCESS! THANK YOU!");
                           csvFile.writeCsvFile(dispensary.inventory);
                           checkoutObservableList.clear();
                           checkoutTableView.refresh();
                           dispensary.total = 0.0;
                           primaryStage.setScene(home);});}
                   else {
                       payButton = new Button("$" + dispensary.total.toString() + "0");
                       payButton.setOnAction(e2 -> {
                           AlertWindow.display("Success", "SUCCESS! THANK YOU!");
                           csvFile.writeCsvFile(dispensary.inventory);
                           checkoutObservableList.clear();
                           checkoutTableView.refresh();
                           dispensary.total = 0.0;
                           primaryStage.setScene(home);});}
                   payButton.setGraphic(payImageView);
                   payButton.setStyle("-fx-font-size: 20; -fx-font-weight: bold");
                   totalBox.getChildren().add(payButton);
                   if (checkoutObservableList.isEmpty()) {
                       AlertWindow.display("Empty Cart", "NOTHING IS IN THE CART!");
                       primaryStage.setScene(home);}}
                catch (Exception e1) {
                   AlertWindow.display("Nothing Selected", "SELECT AN ITEM TO CLEAR");}});

//Pay Button removes items from inventory
           payButton = new Button();
           payButton.setGraphic(payImageView);
           payButton.setStyle("-fx-font-size: 20; -fx-font-weight: bold");
           payButton.setOnAction(e -> {
            AlertWindow.display("Thank You", "Thank you for purchasing ");
            csvFile.writeCsvFile(dispensary.inventory);
            checkoutObservableList.clear();
            checkoutTableView.refresh();
            dispensary.total = 0.0;
            primaryStage.setScene(home);});

//Cart button for each Category
          addDrinksButton = new Button("ADD TO CART");
          addDrinksButton.setMinSize(90, 90);
          addDrinksButton.setOnAction(e -> addButtonAction(drinkTableView, addDrinksButton));

          addChipsButton = new Button("ADD TO CART");
          addChipsButton.setMinSize(90, 90);
          addChipsButton.setOnAction(e -> addButtonAction(chipsTableView, addChipsButton));

          addCandyButton = new Button("ADD TO CART");
          addCandyButton.setMinSize(90, 90);
          addCandyButton.setOnAction(e -> addButtonAction(candyTableView, addCandyButton));

          addGumButton = new Button("ADD TO CART");
          addGumButton.setMinSize(90, 90);
          addGumButton.setOnAction(e -> addButtonAction(gumTableView, addGumButton));

//Drinks Table
          TableColumn<Drink, String> drinkBrand = new TableColumn<>("Brand");
          drinkBrand.setCellValueFactory(new PropertyValueFactory<>("brand"));

          TableColumn<Drink, String> drinkName = new TableColumn<>("Name");
          drinkName.setCellValueFactory(new PropertyValueFactory<>("name"));

          TableColumn<Drink, Double> drinkPrice = new TableColumn<>("Price");
          drinkPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

          TableColumn<Drink, Integer> drinkQuantity = new TableColumn<>("Quantity");
          drinkQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

//Chips Columns
          TableColumn<Chips, String> chipsBrand = new TableColumn<>("Brand");
          chipsBrand.setCellValueFactory(new PropertyValueFactory<>("brand"));

          TableColumn<Chips, String> chipsName = new TableColumn<>("Name");
          chipsName.setCellValueFactory(new PropertyValueFactory<>("name"));
          
          TableColumn<Chips, String> chipsPrice = new TableColumn<>("Price");
          chipsPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

          TableColumn<Chips, Integer> chipsQuantity = new TableColumn<>("Quantity");
          chipsQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

//Candy Columns
          TableColumn<Candy, String> candyBrand = new TableColumn<>("Brand");
          candyBrand.setCellValueFactory(new PropertyValueFactory<>("brand"));

          TableColumn<Candy, String> candyName = new TableColumn<>("Name");
          candyName.setCellValueFactory(new PropertyValueFactory<>("name"));

          TableColumn<Candy, Double> candyPrice = new TableColumn<>("Price");
          candyPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

          TableColumn<Candy, Integer> candyQuantity = new TableColumn<>("Quantity");
          candyQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

//Gum Columns
          TableColumn<Gum, String> gumBrand = new TableColumn<>("Brand");
          gumBrand.setCellValueFactory(new PropertyValueFactory<>("brand"));

          TableColumn<Gum, String> gumName = new TableColumn<>("Name");
          gumName.setCellValueFactory(new PropertyValueFactory<>("name"));

          TableColumn<Gum, Double> gumPrice = new TableColumn<>("Price");
          gumPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

          TableColumn<Gum, Integer> gumQuantity = new TableColumn<>("Quantity");
          gumQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

//Checkout Column
        TableColumn<Inventory, String> checkoutBrand = new TableColumn<>("Brand");
        checkoutBrand.setCellValueFactory(new PropertyValueFactory<>("brand"));

        TableColumn<Inventory, String> checkoutName = new TableColumn<>("Name");
        checkoutName.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Inventory, Double> checkoutPrice = new TableColumn<>("Price");
        checkoutPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

//Inventory Column
        TableColumn<Inventory, String> inventoryBrand = new TableColumn<>("Brand");
        inventoryBrand.setCellValueFactory(new PropertyValueFactory<>("brand"));

        TableColumn<Inventory, String> inventoryName = new TableColumn<>("Name");
        inventoryName.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Inventory, Double> inventoryPrice = new TableColumn<>("Price");
        inventoryPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Inventory, Integer> inventoryQuantity = new TableColumn<>("Quantity");
        inventoryQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));

        dispensary.createDrinks();
        dispensary.createChips();
        dispensary.createGum();
        dispensary.createCandy();
        
//Items in Table for each Item.
        drinkTableView = new TableView<>();
        drinkTableView.setMaxSize(600, 300);
        drinkTableView.setItems(dispensary.drinksTableView(dispensary.inventory));
        drinkTableView.setOnMouseClicked(e -> tableViewAction(drinkTableView, addDrinksButton, drinksStack));
        drinkTableView.setOnKeyPressed(e -> tableViewAction(drinkTableView, addDrinksButton, drinksStack));
        drinkTableView.getColumns().addAll(drinkBrand, drinkName, drinkPrice,drinkQuantity);

        chipsTableView = new TableView<>();
        chipsTableView.setMaxSize(600, 300);
        chipsTableView.setItems(dispensary.chipsTableView(dispensary.inventory));
        chipsTableView.setOnMouseClicked(e -> tableViewAction(chipsTableView, addChipsButton, chipsStack));
        chipsTableView.setOnKeyPressed(e -> tableViewAction(chipsTableView, addChipsButton, chipsStack));
        chipsTableView.getColumns().addAll(chipsBrand, chipsName, chipsPrice, chipsQuantity);

        candyTableView = new TableView<>();
        candyTableView.setMaxSize(600, 300);
        candyTableView.setItems(dispensary.candyTableView(dispensary.inventory));
        candyTableView.setOnMouseClicked(e -> tableViewAction(candyTableView, addCandyButton, candyStack));
        candyTableView.setOnKeyPressed(e -> tableViewAction(candyTableView, addCandyButton, candyStack));
        candyTableView.getColumns().addAll(candyBrand, candyName, candyPrice, candyQuantity);

        gumTableView = new TableView<>();
        gumTableView.setMaxSize(600, 300);
        gumTableView.setItems(dispensary.gumTableView(dispensary.inventory));
        gumTableView.setOnMouseClicked(e -> tableViewAction(gumTableView, addGumButton, gumStack));
        gumTableView.setOnKeyPressed(e -> tableViewAction(gumTableView, addGumButton, gumStack));
        gumTableView.getColumns().addAll(gumBrand, gumName, gumPrice, gumQuantity);

//Checkout TableView
        checkoutTableView = new TableView<>();
        checkoutTableView.setMaxSize(700, 300);
        checkoutTableView.setItems(checkoutObservableList);
        checkoutTableView.getColumns().addAll(checkoutBrand, checkoutName, checkoutPrice);

//Inventory TableView
        inventoryTableView = new TableView<>();
        inventoryTableView.setMaxSize(700, 600);
        inventoryTableView.setItems(globalInventoryManagement.readCurrentInventory(dispensary.inventory));
        inventoryTableView.getColumns().addAll(inventoryBrand, inventoryName, inventoryPrice, inventoryQuantity);

//GridPane HomePage
        GridPane homeCenter = new GridPane();
        homeCenter.setHgap(20);
        homeCenter.setVgap(20);
        homeCenter.setAlignment(Pos.CENTER);
        homeCenter.add(drinksButton, 0, 0);
        homeCenter.add(chipsButton, 1, 0);
        homeCenter.add(candyButton, 0, 1);
        homeCenter.add(gumButton, 1, 1);
        homeRoot.setCenter(homeCenter);

        BorderPane homeBottom = new BorderPane();
        homeBottom.setPadding(new Insets(25, 25, 25, 25));
        homeBottom.setRight(checkoutButton5);
        homeBottom.setLeft(inventoryButton);
        homeRoot.setBottom(homeBottom);

        drinksStack.getChildren().add(addDrinksButton);
        VBox drinksVbox = new VBox();
        drinksVbox.setAlignment(Pos.CENTER);
        drinksVbox.setSpacing(20);
        drinksVbox.getChildren().addAll(drinkTableView, drinkSelectionLabel, drinksStack);
        drinkRoot.setCenter(drinksVbox);

        BorderPane drinksBottom = new BorderPane();
        drinksBottom.setPadding(new Insets(25, 25, 25, 25));
        drinksBottom.setRight(checkoutButton1);
        drinksBottom.setLeft(backButton1);
        drinkRoot.setBottom(drinksBottom);

        chipsStack.getChildren().add(addChipsButton);
        VBox chipsVbox = new VBox();
        chipsVbox.setAlignment(Pos.CENTER);
        chipsVbox.setSpacing(20);
        chipsVbox.getChildren().addAll(chipsTableView, chipSelectionLabel, chipsStack);
        chipsRoot.setCenter(chipsVbox);

        BorderPane chipsBottom = new BorderPane();
        chipsBottom.setPadding(new Insets(25, 25, 25, 25));
        chipsBottom.setLeft(backButton2);
        chipsBottom.setRight(checkoutButton2);
        chipsRoot.setBottom(chipsBottom);

        candyStack.getChildren().add(addCandyButton);
        VBox candyVbox = new VBox();
        candyVbox.setAlignment(Pos.CENTER);
        candyVbox.setSpacing(20);
        candyVbox.getChildren().addAll(candyTableView, candySelectionLabel, candyStack);
        candyRoot.setCenter(candyVbox);

        BorderPane candyBottom = new BorderPane();
        candyBottom.setPadding(new Insets(25, 25, 25, 25));
        candyBottom.setLeft(backButton3);
        candyBottom.setRight(checkoutButton3);
        candyRoot.setBottom(candyBottom);

        gumStack.getChildren().add(addGumButton);
        VBox gumVbox = new VBox();
        gumVbox.setAlignment(Pos.CENTER);
        gumVbox.setSpacing(20);
        gumVbox.getChildren().addAll(gumTableView, gumSelectionLabel, gumStack);
        gumRoot.setCenter(gumVbox);

        BorderPane gumBottom = new BorderPane();
        gumBottom.setPadding(new Insets(25, 25, 25, 25));
        gumBottom.setLeft(backButton4);
        gumBottom.setRight(checkoutButton4);
        gumRoot.setBottom(gumBottom);

        VBox checkoutBox = new VBox();
        checkoutBox.setAlignment(Pos.CENTER);
        checkoutBox.getChildren().addAll(checkoutTableView);
        checkoutRoot.setPadding(new Insets(25, 25, 25, 25));
        checkoutRoot.setCenter(checkoutBox);

        VBox inventoryVBox2 = new VBox(25);
        HBox inventoryHBox = new HBox(25);
        VBox inventoryVBox = new VBox(25);

        BorderPane inventoryBottom = new BorderPane();
        inventoryVBox.setAlignment(Pos.CENTER);
        inventoryVBox.getChildren().addAll(searchButton, lowInventoryPurchase, restockInventory, inventoryCSV,customerQueue, addNewProductButton);
        inventoryVBox2.setAlignment(Pos.CENTER);
        inventoryVBox2.getChildren().addAll(inventoryLabel, inventoryTableView);
        inventoryHBox.setAlignment(Pos.CENTER);
        inventoryHBox.getChildren().addAll(inventoryVBox2, inventoryVBox);
        inventoryBottom.setLeft(backButton6);
        inventoryRoot.setPadding(new Insets(25, 25, 25, 25));
        inventoryRoot.setCenter(inventoryHBox);
        inventoryRoot.setBottom(inventoryBottom);
        totalBox.setAlignment(Pos.CENTER);

        checkoutBottom.setCenter(deleteButton);
        checkoutBottom.setLeft(backButton5);
        checkoutBottom.setRight(payButton);
        checkoutRoot.setBottom(checkoutBottom);

//Displays Primary Stage
        primaryStage.setTitle("Vending Machine Application");
        primaryStage.setScene(home);
        primaryStage.show();}
    
//Checkout Buttons methods
        private void checkoutButtons(Stage primaryStage, Inventory inventory, Scene checkoutScene, ImageView payImageView, Button checkoutButton1) {
            checkoutButton1.setOnAction(e -> {
              if (checkoutObservableList.isEmpty()) {
               AlertWindow.display("ERROR", "Cart is empty!");} 
              else {
                if (dispensary.total.toString().endsWith("25") || dispensary.total.toString().endsWith("75"))
                     payButton.setText("$" + dispensary.total.toString());
                else payButton.setText("$" + dispensary.total.toString() + "0");

//Refresh so total and inventory match
                if (!totalBox.getChildren().isEmpty())
                    totalBox.getChildren().clear();
                totalBox.getChildren().add(payButton);
                checkoutBottom.setRight(totalBox);
                primaryStage.setScene(checkoutScene);}});}

//TableView Methods
        private void tableViewAction(TableView tableView, Button addButton, StackPane stackPane) {
           try {
             Inventory inventory = (Inventory) tableView.getSelectionModel().getSelectedItem();
             Image changingImage = new Image("image/" + inventory.getImage());
             ImageView changingImageView = new ImageView(changingImage);
             changingImageView.setFitHeight(80);
             changingImageView.setFitWidth(80);
             addButton.setGraphic(changingImageView);

             changingImageView2 = new ImageView(changingImage);
             changingImageView2.setFitHeight(80);
             changingImageView2.setFitWidth(80);
             stackPane.getChildren().clear();
             stackPane.getChildren().addAll(changingImageView2, addButton);}
           catch (Exception e) {}}

//Add Button Method
          private void addButtonAction(TableView tableView, Button addButton) {
              Inventory inventory = (Inventory) tableView.getSelectionModel().getSelectedItem();
                try {
                 if (inventory.getQuantity() == 0)
                 AlertWindow.display("Item out of stock", "Item isn't in stock");
                   else {
                   checkoutObservableList.add(inventory);
                   dispensary.total = dispensary.total + inventory.getPrice();
                    inventory.changeQuantity(-1);
                    tableView.refresh();
                    inventoryTableView.refresh();
                    translate.setNode(changingImageView2);
                    translate.play();
                    scaleTransition.setNode(changingImageView2);
                    scaleTransition.play();
                    tableView.getSelectionModel().clearSelection();
                    addButton.setGraphic(null);}}
            catch (Exception e) {
            AlertWindow.display("No Selection", "Nothing Selected");}}}

