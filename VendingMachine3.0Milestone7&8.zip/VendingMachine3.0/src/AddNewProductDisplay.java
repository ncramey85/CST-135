// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class AddNewProductDisplay {

//Variables 
    private double price;
    private String name, image, productID, brand, productType;
    private int quantity;

    public ObservableList<Inventory> addNewProduct(ObservableList<Inventory> inventory, ObservableList<Drink> drinksList, ObservableList<Chips> chipsList, ObservableList<Candy> candyList, ObservableList<Gum> gumList) {

//Stage Declared
        Stage primaryStage = new Stage();

//Scenes Declared
        Scene home, drinksScene, chipsScene, candyScene, gumScene, checkoutScene, inventoryScene;

//Root Layout
        VBox homeRoot = new VBox(10);
        homeRoot.setPadding(new Insets(25, 25, 25, 25));
        homeRoot.setAlignment(Pos.BASELINE_LEFT);
        VBox drinkRoot = new VBox(10);
        drinkRoot.setPadding(new Insets(25, 25, 25, 25));
        drinkRoot.setAlignment(Pos.BASELINE_LEFT);
        VBox chipsRoot = new VBox(10);
        chipsRoot.setPadding(new Insets(25, 25, 25, 25));
        chipsRoot.setAlignment(Pos.BASELINE_LEFT);
        VBox candyRoot = new VBox(10);
        candyRoot.setPadding(new Insets(25, 25, 25, 25));
        candyRoot.setAlignment(Pos.BASELINE_LEFT);
        VBox gumRoot = new VBox(10);
        gumRoot.setPadding(new Insets(25, 25, 25, 25));
        gumRoot.setAlignment(Pos.BASELINE_LEFT);

//Scenes Sets
        home = new Scene(homeRoot, 800, 600);
        drinksScene = new Scene(drinkRoot, 800, 600);
        chipsScene = new Scene(chipsRoot, 800, 600);
        candyScene = new Scene(candyRoot, 800, 600);
        gumScene = new Scene(gumRoot, 800, 600);

//Option box to what user wants to add to Vending Machine
        ChoiceBox<String> productTypeChoiceBox = new ChoiceBox<>();
        productTypeChoiceBox.setStyle("-fx-font-size: 26");
        productTypeChoiceBox.getItems().addAll("DRINK", "CHIPS", "CANDY", "GUM");
        productTypeChoiceBox.setValue("DRINK");

        Label productTypeSelectLabel = new Label("Select Type to add");
        productTypeSelectLabel.setStyle("-fx-font-size: 26");
        Label imageLabel = new Label("IMPORTANT: Ensure Image Selected matches one in Image Folder");

        Image backImage = new Image("image/back.png");
        ImageView backImageView = new ImageView(backImage);
        backImageView.setFitHeight(40);
        backImageView.setFitWidth(40);
        Button backButton2 = new Button();
        backButton2.setGraphic(backImageView);
        backButton2.setOnAction(e -> primaryStage.close());

        TextField priceTextField = new TextField("Price");
        priceTextField.setFocusTraversable(false);
        priceTextField.setOnMouseClicked(e -> {
            if (priceTextField.getText().equals("Price"))
                priceTextField.clear();});
        TextField nameTextField = new TextField("Name");
        nameTextField.setFocusTraversable(false);
        nameTextField.setOnMouseClicked(e -> {
            if (nameTextField.getText().equals("Name"))
                nameTextField.clear();});
        TextField imageTextField = new TextField("Image File Name Stored");
        imageTextField.setFocusTraversable(false);
        imageTextField.setOnMouseClicked(e -> {
            if (imageTextField.getText().equals("Image File Name Stored"))
                imageTextField.clear();});
        TextField quantityTextField = new TextField("Quantity");
        quantityTextField.setFocusTraversable(false);
        quantityTextField.setOnMouseClicked(e -> {
            if (quantityTextField.getText().equals("Quantity"))
                quantityTextField.clear();});
        TextField productIDTextField = new TextField("Product ID");
        productIDTextField.setFocusTraversable(false);
        productIDTextField.setOnMouseClicked(e -> {
            if (productIDTextField.getText().equals("Product ID"))
                productIDTextField.clear();});
        TextField brandTextField = new TextField("Brand");
        brandTextField.setFocusTraversable(false);
        brandTextField.setOnMouseClicked(e -> {
            if (brandTextField.getText().equals("Brand"))
                brandTextField.clear();});
        Button createProductButton = new Button("Create");

        Button backButton = new Button("Go Back");
        backButton.setOnAction(e -> {
            drinkRoot.getChildren().clear();
            chipsRoot.getChildren().clear();
            candyRoot.getChildren().clear();
            gumRoot.getChildren().clear();
            primaryStage.setScene(home);});

        Button productTypeButton = new Button("OK");
        productTypeButton.setStyle("-fx-font-size: 26");
        productTypeButton.setOnAction(e -> {
            getChoice(productTypeChoiceBox);
            if (productType.equals("DRINK")) {
                createProductButton.setOnAction(e1 -> {
                    try {
                        name = nameTextField.getText();
                        brand = brandTextField.getText();
                        price = Double.parseDouble(priceTextField.getText());
                        image = imageTextField.getText();
                        quantity = Integer.parseInt(quantityTextField.getText());
                        productID = productIDTextField.getText();}
                     catch (Exception e2) {
                        AlertWindow.display("ERROR", "Error Adding Product. \n Check data.");
                        productTypeChoiceBox.setValue("DRINK");
                        productTypeButton.fire();}
                    
                    Drink product;
                    product = new Drink(name, brand, price, image, quantity, productID);
                    inventory.add(product);
                    drinksList.add(product);
                    AlertWindow.display("SUCCESS", "Successfully Added");
                    primaryStage.close();});

                if (drinkRoot.getChildren().isEmpty())
                    drinkRoot.getChildren().addAll(nameTextField, brandTextField, priceTextField, imageTextField, quantityTextField, productIDTextField, imageLabel, createProductButton, backButton);

                primaryStage.setScene(drinksScene);}
             else if (productType.equals("CHIPS")) {
                createProductButton.setOnAction(e1 -> {
                    drinkRoot.getChildren().clear();
                    chipsRoot.getChildren().clear();
                    candyRoot.getChildren().clear();
                    gumRoot.getChildren().clear();
                    try {
                        name = nameTextField.getText();
                        brand = brandTextField.getText();
                        price = Double.parseDouble(priceTextField.getText());
                        image = imageTextField.getText();
                        productID = productIDTextField.getText();}
                     catch (Exception e2) {
                        AlertWindow.display("ERROR", "Error Adding Product. \n Check Data.");}
                    Chips product;
                    product = new Chips(name, brand, price, image, quantity, productID);
                    inventory.add(product);
                    chipsList.add(product);
                    AlertWindow.display("SUCCESS", "Successfully Added");
                    primaryStage.close();});

                if (chipsRoot.getChildren().isEmpty())
                    chipsRoot.getChildren().addAll(nameTextField, brandTextField, priceTextField, imageTextField, quantityTextField, productIDTextField, imageLabel, createProductButton, backButton);

                primaryStage.setScene(chipsScene);}
             else if (productType.equals("CANDY")) {
                createProductButton.setOnAction(e1 -> {
                    drinkRoot.getChildren().clear();
                    chipsRoot.getChildren().clear();
                    candyRoot.getChildren().clear();
                    gumRoot.getChildren().clear();
                    try {
                        name = nameTextField.getText();
                        brand = brandTextField.getText();
                        price = Double.parseDouble(priceTextField.getText());
                        image = imageTextField.getText();
                        productID = productIDTextField.getText();}
                     catch (Exception e2) {
                        AlertWindow.display("ERROR", "Error Adding Product. \n Check Data.");}
                    
                    Candy product;
                    product = new Candy(name, brand, price, image, quantity, productID);
                    inventory.add(product);
                    candyList.add(product);
                    AlertWindow.display("SUCCESS", "Successfully Added");
                    primaryStage.close();});

                if (candyRoot.getChildren().isEmpty())
                    candyRoot.getChildren().addAll(nameTextField, brandTextField, priceTextField, imageTextField, productIDTextField, imageLabel, createProductButton, backButton);

                primaryStage.setScene(candyScene);}
             else if (productType.equals("GUM")) {
                createProductButton.setOnAction(e1 -> {
                    drinkRoot.getChildren().clear();
                    chipsRoot.getChildren().clear();
                    candyRoot.getChildren().clear();
                    gumRoot.getChildren().clear();
                    try {
                        name = nameTextField.getText();
                        brand = brandTextField.getText();
                        price = Double.parseDouble(priceTextField.getText());
                        image = imageTextField.getText();
                        quantity = Integer.parseInt(quantityTextField.getText());
                        productID = productIDTextField.getText();}
                     catch (Exception e2) {
                        AlertWindow.display("ERROR", "Error Adding Product. \n Check Data.");}

                    Gum product;
                    product = new Gum(name, brand, price, image, quantity, productID);
                    inventory.add(product);
                    gumList.add(product);
                    AlertWindow.display("Success", "PRODUCT ADDED");
                    primaryStage.close();});

                if (gumRoot.getChildren().isEmpty())
                    gumRoot.getChildren().addAll(nameTextField, brandTextField, priceTextField, imageTextField, quantityTextField, productIDTextField, imageLabel, createProductButton, backButton);

                primaryStage.setScene(gumScene);}});

        homeRoot.setAlignment(Pos.CENTER);
        homeRoot.getChildren().addAll(productTypeSelectLabel, productTypeChoiceBox, productTypeButton, backButton2);

//Primary Stage Displayed 
        primaryStage.setTitle("Vending Machine Application");
        primaryStage.setScene(home);
        primaryStage.showAndWait();

        return inventory;}

    private void getChoice(ChoiceBox<String> productTypeChoiceBox) {
        productType = productTypeChoiceBox.getValue();}}

