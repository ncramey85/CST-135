// This is our own work by Nate R. Vincent C.
// CST-135 Professor Mneimneh
// September 21, 2018

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Restock {

    ObservableList<Inventory> localInventory = FXCollections.observableArrayList();
    private static Scanner sc;

    public void restockProducts(ObservableList<Inventory> inventory) {
        String csvFile = "PO.csv";
        try {
            sc = new Scanner(new File(csvFile));
            sc.useDelimiter("[,\n]");

//Ignores Header Line
    String header = sc.nextLine();
       while (sc.hasNextLine()) {
         String nextLine = sc.nextLine();
         String[] lineArray = nextLine.split(",");
         String name = lineArray[0];
         String strPrice = lineArray[1];
         double price = Double.parseDouble(strPrice);
         String strQuantity = lineArray[2];
         int quantity = Integer.parseInt(strQuantity);
         String productID = lineArray[3];

//Read from proper format.
         String strProductTotal = lineArray[4];
         double productTotal = Double.parseDouble(strProductTotal);
         String strTransactionTotal = lineArray[5];
         double transactionTotal = Double.parseDouble(strTransactionTotal);

         Inventory inventory1 = new Inventory(name, price, quantity, productID);
         localInventory.add((Inventory) inventory);}}
            
       catch (Exception e) {
           AlertWindow.display("ERROR", "Error");
           e.printStackTrace();}
        
//Compares and updates Inventory
        for (Inventory inventory1 : inventory) {
          for (Inventory purchaseProduct : localInventory) {
          if (inventory1.productID.equals(purchaseProduct.getProductID()))
                    inventory1.changeQuantity(purchaseProduct.quantity);}}}

//PO for restocking a product that gets below 5 
    public void purchaseLowProducts(ObservableList<Inventory> localInventory) {
        int i = 0;
        int qty;
        double productTotal;
        double transactionTotal = 0;

//.csv File delimiter
        final String COMMA_DELIMITER = ",";
        final String NEW_LINE_SEPARATOR = "\n";

//Write .csv PO
        FileWriter fileWriter = null;

//Deletes and overwrites existing inventory
        try {
            File file = new File("PO.csv");
            file.delete();}
         catch (Exception e) {
            AlertWindow.display("ERROR", "Error deleting previous .csv file");}
        try {
            fileWriter = new FileWriter("Purchase Order.csv");}
         catch (Exception e) {
            AlertWindow.display("ERROR", "Unable to open .csv file");}
        
//.csv File Header
        final String FILE_HEADER = "Name, Price, Quantity, ProductID, Product Total, Running Total";
        try {
//Write .csv file header
            fileWriter.append(FILE_HEADER.toString());

//Line Separator
            fileWriter.append(NEW_LINE_SEPARATOR);}
        catch (Exception e) {
            AlertWindow.display("ERROR", "Error writing in .csv file");}
        for (Inventory inventory : localInventory) {
            if (inventory.quantity <= 3) {
                qty = 20 - inventory.quantity;
                productTotal = qty * inventory.getPrice();
                transactionTotal = transactionTotal + productTotal;

//Write product in .csv file
         try {
          fileWriter.append(String.valueOf(inventory.getName()));
          fileWriter.append(COMMA_DELIMITER);
          fileWriter.append(String.valueOf(inventory.getPrice()));
          fileWriter.append(COMMA_DELIMITER);
          fileWriter.append(String.valueOf(qty));
          fileWriter.append(COMMA_DELIMITER);
          fileWriter.append(String.valueOf(inventory.getProductID()));
          fileWriter.append(COMMA_DELIMITER);
          fileWriter.append(String.valueOf(productTotal));
          fileWriter.append(COMMA_DELIMITER);
          fileWriter.append(String.valueOf(transactionTotal));
          fileWriter.append(NEW_LINE_SEPARATOR);}
            catch (Exception e) {
               AlertWindow.display("ERROR", "Error writing to file");}}
            i++;}
        try {
            fileWriter.flush();
            fileWriter.close();}
         catch (IOException e) {
            AlertWindow.display("ERROR", "Error Closing File");}}}
